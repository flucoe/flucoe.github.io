function [sh,sh_jg,sh_g] = shares2(p,a, s, xi, Model)

if Model~= 1 && Model~=2
    disp("Model must be 1 or 2 for the Logit and Nested Logit models, respectively")
    
elseif Model==1
    sh = exp(a*p + xi) / (exp(d) + sum(exp(a*p + xi)));
    
elseif Model==2
    sh_jg = exp((a/s)*p + (xi/s))/ (sum(exp((a/s)*p + (xi/s))));
    sh_g = ((sum(exp((a/s)*p + (xi/s))))^s) / (1 + (sum(exp((a/s)*p + (xi/s))))^s);
    sh = sh_jg.*sh_g;
end
    


end
    