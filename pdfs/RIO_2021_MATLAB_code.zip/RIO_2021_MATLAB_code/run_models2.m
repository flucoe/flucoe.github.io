function [Prices, EL, SH, DSH,EXITFLAG_NL_0, EXITFLAG_NL_1] = run_models2(param,w0,cw,cr)

% This script computes equilibrium wholesale and retail prices for both the
% Logit and Nested Logit specifications used in the paper. In both cases,
% we explore how eq. wholesale and retail prices depend on the underlying
% parameters of the models.

global J 
J=2;

l = param(1);
a = param(2);
s = param(3);
xi = param(4:5)';

%% Nested-Logit
options=optimoptions('fsolve','Algorithm','trust-region','Display','off','FunctionTolerance',1e-8);

    % No VI
        VI = 0;
        penalty=10;
        [w_opt_NL_0,foc_opt_NL_0,EXITFLAG_NL_0] = fsolve(@(w) FOC2(w, cr, cw, a, s, xi, VI,2,penalty, l),w0,options);
%         EXITFLAG_NL_0
        p0 = w_opt_NL_0 + cr; % To use as starting point

        [p_opt_NL_0,focr_opt_NL_0,EXITFLAG_NL_R_0] = fsolve(@(p) FOC_retailer2(p, cr, a, s, xi, w_opt_NL_0,2, l),p0,options);

        el0 = elast(p_opt_NL_0,a, s, xi,2);
        sh0 = shares2(p_opt_NL_0,a, s, xi, 2);
        [dSdP0, ~ ] = dsh_dretP2(p_opt_NL_0,a, s, xi, 2);

    % VI
        VI = 1;
        w0_VI=w0(2);
        penalty=w_opt_NL_0(2);
        [w_opt_VI_NL_1,foc_opt_NL_1,EXITFLAG_NL_1] = fsolve(@(w) FOC2(w, cr, cw, a, s, xi, VI,2,penalty, l),w0_VI,options);
        w_opt_VI_NL_1 = [cw(2);w_opt_VI_NL_1];
% EXITFLAG_NL_1
        p0 = w_opt_VI_NL_1 + cr; % To use as starting point

        [p_opt_VI_NL_1,focr_opt_1,EXITFLAG_NL_R_1] = fsolve(@(p) FOC_retailer2(p, cr, a, s, xi, w_opt_VI_NL_1,2, l),p0,options);
        sh1 = shares2(p_opt_VI_NL_1,a, s, xi, 2);
        el1 = elast(p_opt_VI_NL_1,a, s, xi, 2);
        [dSdP1, ~ ] = dsh_dretP2(p_opt_VI_NL_1,a, s, xi, 2);
        DSH=[dSdP0,dSdP1];
        EL = [el0, el1];
        SH = [sh0,sh1];
        
%% Put all prices (retail and wholesale) in the same matrix to export

Prices(:,:,1) = [p_opt_NL_0 p_opt_VI_NL_1];
Prices(:,:,2) = [w_opt_NL_0 w_opt_VI_NL_1];



end

