function [dSdP, dS2dP2 ] = dsh_dretP2(p,a, s, xi, Model)

% HELP: This script computes two arrays of partial derivatives of the
% shares with respect to *retail* prices.

% The first array, dSdP is of dimensions JxJ, where J is the number of
% products in the market.

% Element (i,j) of dSdP is ds_i / dp_j. If i==j, this is
% (remember that "a" is negative) a*s_i*(1-s_i). If i~=j, this is
% -a*s_i*s_j.

% The second array, dS2dP2 is of dimensions JxJxJ, where J is the number of
% products in the market.

% The array dS2dP2(:,:,k) corresponds to the matrix of second derivatives of the
% share of product k with respect to retail prices. The element (i,j,k)
% corresponds to d2 s_k / d p_i d p_j. This is, if i=j=k=1, the element (1,1,1)
% is d2 s_1 / d p_1^2. If i=k=1 and j=1, the element (1,2,1) is d2 s_1 / d p_1 d p_2.
% In this way, the first array is given by
% dS2dP2(:,:,1) = [ d2 s_1 / d p_1^2     d2 s_1 / d p_1 d p_2;
%                    d2 s_1 / d p_2 d p_1  d2 s_1 / d p_2^2 ],
% and the second array is
% dS2dP2(:,:,2) = [ d2 s_2 / d p_1^2     d2 s_2 / d p_1 d p_2;
%                    d2 s_2 / d p_2 d p_1  d2 s_2 / d p_2^2 ].

% Replacing the second derivatives we have:
% dS2dP2(:,:,1) = [ -(a)^2 s1(1-s1)(2s1-1)     (-a)^2 s1s2(2s1-1)
%                    (-a)^2 s2s1(2s1-1)      (-a)^2 s1s2 (2s1-1)], and
% dS2dP2(:,:,2) = [ a^2 s1s2(2s1-1)     (-a)^2 s1s2(2s2-1)
%                    (-a)^2 s1s2(2s2-1)      -(a)^2 s2(1-s2)(2s2-1)].
%

% Finally, the matrix dP/dW can be computed as
% dPdW = inv(D)*dSdP', where D has the form:

% D = [ [ds1/dp1 + d2s1/dp1^2 M1 + d2s2/dp1^2 M2 + ds1/dp1] [ds1/dp2 + d2s1/dp1dp2 M1 + d2s2/dp1 dp2 M2 + ds2/dp1];
% [ds2/dp1 + d2s1/dp2 dp1 M1 + d2s2/dp2dp1 M2 + ds1/dp2] [ds2/dp2 +
% d2s1/dp2^2 M1 + d2s2/dp2^2 M2 + ds2/dp2]], where M1 and M2 are retail
% margins for products 1 and 2, respectively.

global J

if Model~= 1 && Model~=2
    disp("Model must be 1 or 2 for the Logit and Nested Logit models, respectively")
    
elseif Model==1
    
    sh = shares2(p,a, s, xi, 1);
    
    dSdP = a * (-sh*sh' + diag(diag(sh*sh')) + diag(sh.*(1-sh)));
    
    dS2dP2= zeros(J,J,J);
    
    dS2dP2(1,1,1) = -(a^2) * sh(1) * (1-sh(1)) * (2*sh(1)-1);
    dS2dP2(1,2,1) = (-a)^2 * sh(1) * sh(2) * (2 * sh(1) -1);
    dS2dP2(2,1,1) = (-a)^2 * sh(1) * sh(2) * (2 * sh(1) -1);
    dS2dP2(2,2,1) = (-a)^2 * sh(1) * sh(2) * (2 * sh(2) -1);
    
    dS2dP2(1,1,2) = (-a)^2 * sh(2) * sh(1) * (2 * sh(1) -1);
    dS2dP2(1,2,2) = (-a)^2 * sh(2) * sh(1) * (2 * sh(2) -1);
    dS2dP2(2,1,2) = (-a)^2 * sh(2) * sh(1) * (2 * sh(2) -1);
    dS2dP2(2,2,2) = -(a^2) * sh(2) * (1 - sh(2) ) * (2 * sh(2) - 1);
    
    
elseif Model==2
    
    [sh,sh_jg,sh_g] = shares2(p,a, s, xi, 2);
    

    
%element i,j is d s_{i|g} / dp_j
dSjg_dP = a/s * (-sh_jg*sh_jg' + diag(diag(sh_jg*sh_jg')) + diag(diag(sh_jg.*(1-sh_jg'))));

%element i,1 is d s_{g} / dp_i
dSg_dP = a * sh_jg * sh_g * (1 - sh_g);

%element i,j is d s_i / dp_j
dS_dP = diag(a/s*sh_jg*sh_g.*(1-s*sh-(1-s)*sh_jg)) + (ones(2)-eye(2)).*(-a/s*(sh_jg*sh_jg')*sh_g*(1- s + s*sh_g));

%element i,j is d^2 s_g / dp_i dp_j
d2Sg_dPdP = a*sh_g*(1-sh_g)*dSjg_dP + a*(1-sh_g)*sh_jg*dSg_dP' - a  *sh*dSg_dP';

%element i,j,h is d^2 s_{h|g}/dp_i dp_j
d2Sjg_dPdP=zeros(2,2,2);
d2Sjg_dPdP(:,:,1)=[a/s*dSjg_dP(1,:)*(1-sh_jg(1))-a/s*sh_jg(1)*dSjg_dP(1,:);
 -a/s*(dSjg_dP(1,:)*sh_jg(2) + dSjg_dP(2,:)*sh_jg(1))   ];
d2Sjg_dPdP(:,:,2)=[ -a/s*(dSjg_dP(1,:)*sh_jg(2) + dSjg_dP(2,:)*sh_jg(1));
   a/s*dSjg_dP(2,:)*(1-sh_jg(2))-a/s*sh_jg(2)*dSjg_dP(2,:) ];
    
%element i,j,h is d^2 s_h/dp_i dp_j 
d2sj_dPdP = zeros(J,J,J);
for h=1:J
d2sj_dPdP(:,:,h)=d2Sg_dPdP*sh_jg(h) + sh_g*d2Sjg_dPdP(:,:,h) + dSg_dP*dSjg_dP(h,:)+dSjg_dP(h,:)'*dSg_dP';
end
    
    dSdP = dS_dP;
    dS2dP2 = d2sj_dPdP;
    
        
end



end
