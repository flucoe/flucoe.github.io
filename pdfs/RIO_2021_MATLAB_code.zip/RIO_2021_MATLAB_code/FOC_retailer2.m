function foc_ret = FOC_retailer2(p, cr, a, s, xi, w, Model, l)

% Shares at candidate prices

sh = shares2(p,a, s, xi, Model);

[Dr,~]  = dsh_dretP2(p,a, s, xi, Model);

foc_ret = Dr* (p-w-cr) + (l* sh);


end