clear
clear all
clc
clear global
global J
% Set seed
rng(1)
% Number of products
J=2 ;

% Initial prices
cw = 0.5*ones(J,1); % Wholesale marginal costs.
cr = 0.5*ones(J,1); % Retail marginal costs.
w0 = cw;

%% With xi
A=[-1;-1.5; -2];
S = [0.5;0.7;0.9];
param = [kron(A,ones(length(S),1)), kron(ones(length(A),1),S)];

for k=1:length(param),
xi1 = [0.5:0.05:2]';
xi2 = xi1;
xi = [xi1 xi2];
a = param(k,1);
s = param(k,2);

Parameters = [a*ones(size(xi,1),1), s*ones(size(xi,1),1), xi];

P = zeros(J,J,J,length(Parameters));
EL = zeros(J,2*J,length(Parameters));
SH = zeros(J,J,length(Parameters));

EXITFLAGS1 = zeros(length(Parameters),1);
EXITFLAGS2 = zeros(length(Parameters),1);

tic
for i = 1:length(Parameters)
    [P(:,:,:,i), EL(:,:,i), SH(:,:,i),DSH(:,:,i), EXITFLAGS1(i,1), EXITFLAGS2(i,1)] = run_models2([1,Parameters(i,:)],w0,cw,cr);
end
toc

PriceRatioOwn(:,k) = (reshape(P(1,2,1,:),length(Parameters),1)./reshape(P(1,1,1,:),length(Parameters),1));
PriceRatioRival(:,k) = (reshape(P(2,2,1,:),length(Parameters),1)./reshape(P(2,1,1,:),length(Parameters),1));
PriceRatioPost(:,k) = (reshape(P(2,2,1,:),length(Parameters),1)./reshape(P(1,2,1,:),length(Parameters),1));

ELown(:,k)=(reshape(EL(1,1,:),length(Parameters),1));
ELcross(:,k)=(reshape(EL(1,2,:),length(Parameters),1));
dsh_own_pre(:,k)=(reshape(DSH(1,1,:),length(Parameters),1));
dsh_own_post(:,k)=(reshape(DSH(1,3,:),length(Parameters),1));
dsh_cross_pre(:,k)=(reshape(DSH(2,1,:),length(Parameters),1));
dsh_cross_post(:,k)=(reshape(DSH(2,3,:),length(Parameters),1));
DiversionPRE(:,k)=-dsh_cross_pre(:,k)./dsh_own_pre(:,k);
DiversionPOST(:,k)=-dsh_cross_post(:,k)./dsh_own_post(:,k);
Diversion(:,k)=-ELcross(:,k)./ELown(:,k);
end

%%

c = gray(length(param));

close all
figure
Legend=cell(length(param),1);
for k=1:length(param),
plot(xi1,PriceRatioOwn(:,k),'color',c(k,:)); hold on
Legend{k}=strcat('\alpha= ', num2str(-param(k,1)), ', \sigma= ', num2str(param(k,2)));
end
legend(Legend,'Location','southeast')
legend('boxoff')
xlabel('\xi_1 = \xi_2 = \xi','FontSize',20)
ylabel('Price ratio','FontSize',20)
hold off
saveas(gcf,'figures/effect_on_own_price_by_xi_g.pdf')

close all
figure
Legend=cell(length(param),1);
for k=1:length(param),
plot(xi1,PriceRatioRival(:,k),'color',c(k,:)); hold on
Legend{k}=strcat('\alpha= ', num2str(-param(k,1)), ', \sigma= ', num2str(param(k,2)));
end
legend(Legend,'Location','southeast')
legend('boxoff')
xlabel('\xi_1 = \xi_2 = \xi','FontSize',20)
ylabel('Price ratio','FontSize',20)
hold off
saveas(gcf,'figures/effect_on_rival_price_by_xi_g.pdf')

close all
figure
Legend=cell(length(param),1);
for k=1:length(param),
plot(xi1,PriceRatioPost(:,k),'color',c(k,:)); hold on
Legend{k}=strcat('\alpha= ', num2str(-param(k,1)), ', \sigma= ', num2str(param(k,2)));
end
legend(Legend,'Location','southeast')
legend('boxoff')
xlabel('\xi_1 = \xi_2 = \xi','FontSize',20)
ylabel('Price ratio post','FontSize',20)
hold off
saveas(gcf,'figures/priceratiopost_by_xi_g.pdf')

close all
figure
Legend=cell(length(param),1);
for k=1:length(param),
plot(xi1,Diversion(:,k),'color',c(k,:)); hold on
Legend{k}=strcat('\alpha= ', num2str(-param(k,1)), ', \sigma= ', num2str(param(k,2)));
end
legend(Legend,'Location','southeast')
legend('boxoff')
xlabel('\xi_1 = \xi_2 = \xi','FontSize',20)
ylabel('Diversion','FontSize',20)
hold off
saveas(gcf,'figures/diversion_by_xi_g.pdf')

