function el = elast(RetailPrices,a, s, xi, Model)

sh = shares2(RetailPrices,a, s, xi, Model);
[Dr,~]  = dsh_dretP2(RetailPrices,a, s, xi, Model);

P = ones(2,1)*RetailPrices';
S = sh*ones(1,2);

el = (Dr./S).*P;
end
