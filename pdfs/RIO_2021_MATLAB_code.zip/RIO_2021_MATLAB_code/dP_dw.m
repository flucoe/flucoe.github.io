function dPdw = dP_dw(p,w,cr,dSdP, dS2dP2)

% HELP: This script computes the matrix of derivatives of retail prices wrt
% wholesale prices. Note that the expression derived here is the same
% regardless of whether the Logit or Nested Logit is modeled.

% For the logit model, the arrays of first and second derivatives are given by:

% dSdP(i,j) = ds_i / dp_j. If i==j, this is (remember that "a" is negative)
% a*s_i*(1-s_i). If i~=j, this is -a*s_i*s_j.

% dS2dP2(:,:,1) = [ d2 s_1 / d p_1^2     d2 s_1 / d p_1 d p_2;
%                    d2 s_1 / d p_2 d p_1  d2 s_1 / d p_2^2 ],
% and the second array is
% dS2dP2(:,:,2) = [ d2 s_2 / d p_1^2     d2 s_2 / d p_1 d p_2;
%                    d2 s_2 / d p_2 d p_1  d2 s_2 / d p_2^2 ].

% Replacing the second derivatives we have:
% dS2dP2(:,:,1) = [ -(a)^2 s1(1-s1)(2s1-1)     (-a)^2 s1s2(2s1-1)
%                    (-a)^2 s2s1(2s1-1)      (-a)^2 s1s2 (2s1-1)], and
% dS2dP2(:,:,2) = [ a^2 s1s2(2s1-1)     (-a)^2 s1s2(2s2-1)
%                    (-a)^2 s1s2(2s2-1)      -(a)^2 s2(1-s2)(2s2-1)].



margin_ret = p-w-cr;

v1 = [1; margin_ret; 1];

Der11 = [dSdP(1,1) dS2dP2(1,1,1) dS2dP2(1,1,2) dSdP(1,1)];

Der12 = [dSdP(1,2) dS2dP2(1,2,1) dS2dP2(1,2,2) dSdP(2,1)];

Der21 = [dSdP(2,1) dS2dP2(2,1,1) dS2dP2(2,1,2) dSdP(1,2)];

Der22 = [dSdP(2,2) dS2dP2(2,2,1) dS2dP2(2,2,2) dSdP(2,2)];

Der = [Der11*v1 Der12*v1; 
        Der21*v1 Der22*v1];

%element i,j is dp_i/dw_k    
dPdw = Der\(dSdP');

end
