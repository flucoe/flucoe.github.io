function foc= FOC2(w, cr, cw, a, s, xi, VI,Model,penalty, l)

% HELP: This script computes retail and wholesale prices given all matrices
% of derivatives (that are a function of these prices), pass-through, and 
% marginal costs (both retail and wholesale marginal costs).

global J

%% Downstream (takes w as given)

optR=optimoptions('fsolve','Algorithm','trust-region','Display','off');

if VI==1
    w = [cw(1);w];
end

p0 = w + cr; % To use as starting point

[p_opt,focr_opt,EXITFLAG] = fsolve(@(p) FOC_retailer2(p, cr, a, s, xi, w, Model, l),p0,optR);

RetailPrices = p_opt;


% Upstream firms

sh = shares2(RetailPrices,a, s, xi, Model);

[Dr,Dr2]  = dsh_dretP2(RetailPrices,a, s, xi, Model);

DpDw = dP_dw(RetailPrices,w,cr,Dr, Dr2);

%element i,j is ds_i/dw_j
Dw = Dr * DpDw;
T = eye(J);
foc = (T.*Dw) * (w-cw) + sh;

if VI==1
foc = foc(2,1);
    if w(2)>penalty
        foc = 10;
    end
end


end
